/**
 * <h1>Hussein's Binary Search Tree</h1>
 * @since 2 April 2017
 * @author Hussein Suleman
 *
*/

public class BinarySearchTree<dataType extends Comparable<? super dataType >> extends BinaryTree<dataType >
{
  /**
   * This class inherits from BinaryTree class and manages data
   * structure operations
   * Modified to include insert counter in the insert method
  */

  /**
   * Global instance variables
   * Initialising insert and search counters
   * @param opCount sets the search opertion counter to 0
   * @param inCount sets the insert opertion counter to 0
  */

  static int opCount = 0;
  static int inCount = 0;

  public void insert ( Dam d )
  {
     inCount();
     if (root == null)
        root = new BinaryTreeNode<dataType> (d, null, null);

     else
        insert (d, root);
  }

  public void insert ( Dam d, BinaryTreeNode<dataType> node )
  {
    /**
     * When inserting a node, it checks value of argument d and then
     * traverses down the right or left subtree deapending on value
     * creates new node at a null position
    */
     inCount();
     if (d.toString().compareTo (node.data) <= 0)
     {
        if (node.left == null)
           node.left = new BinaryTreeNode<dataType> (d, null, null);
        else
           insert (d, node.left);
     }

     else
     {
        if (node.right == null)
           node.right = new BinaryTreeNode<dataType> (d, null, null);
        else
           insert (d, node.right);
     }
  }

  public BinaryTreeNode<dataType> find ( String d )
  {
    /**
     * When invoked, calls the recursive find method
    */
     if (root == null)
	        return null;
     else
	        return find (d, root);
  }

  public BinaryTreeNode<dataType> find ( String d, BinaryTreeNode<dataType> node )
  {
    /**
     * @param d is compared to every node data
     * Moves to left or right subtree depending on value of d
     * Counts number of comparison operations made when searching
     * @return node if found
    */

     opCount();
     int position = (node.data).indexOf(",");
     if (d.compareTo ((node.data).substring(0, position)) == 0)
        return node;

     else if (d.compareTo ((node.data).substring(0, position)) < 0)
        return (node.left == null) ? null : find (d, node.left);

     else
        return (node.right == null) ? null : find (d, node.right);
  }

  public void opCount ()
  {
    /**
     * @param opCount is incremented at each invocation
    */
     opCount++;
  }

  public void inCount()
  {
     /**
      * @param inCount is incrementedat each invocation
     */
     inCount++;
  }

  public int getOpCount ()
  {
    /**
     * @return opCount
    */
    return opCount;
  }

  public int getInCount()
  {
   /**
    * @return inCount
   */
    return inCount;
  }

}
