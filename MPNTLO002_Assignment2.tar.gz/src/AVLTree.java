/**
 * <h1>Hussein's AVL Tree</h1>
 * @since 2 April 2017
 * @author Hussein Suleman
 * reference: kukuruku.co/post/avl-trees/
 *
*/

public class AVLTree<dataType extends Comparable<? super dataType>> extends BinaryTree<dataType>
{
   /**
    * This class inherits from BinaryTree class and manages data
    * structure operations
    * Modified to include insert counter in the insert method
   */

   /**
    * Global instance variables
    * Initialising insert and search counters
    * @param opCount sets the search opertion counter to 0
    * @param inCount sets the insert opertion counter to 0
   */
   static int opCount = 0;
   static int inCount = 0;

   public int height ( BinaryTreeNode<dataType> node )
   {
      /**
       * Rerturns the height of a non-null node
       * @param height  returns the value of the variable height in the
       * BinaryTreeNode class
       * -1 is returned if node has no value
      */
      if (node != null)
         return node.height;
      return -1;
   }

   public int balanceFactor ( BinaryTreeNode<dataType> node )
   {
      /**
       * Calculates difference in height of left and right subtrees
       * of the node
      */
      return height (node.right) - height (node.left);
   }

   public void fixHeight ( BinaryTreeNode<dataType> node )
   {
      /**
       * Calculates the height of the tree when invoked
      */
      node.height = Math.max (height (node.left), height (node.right)) + 1;
   }

   public BinaryTreeNode<dataType> rotateRight ( BinaryTreeNode<dataType> p )
   {
      /**
       * Makes a single right rotation of a nodes
       * Rotates to the right by replacing the left child with the right child
       * @return the rotated node
      */
      BinaryTreeNode<dataType> q = p.left;
      p.left = q.right;
      q.right = p;
      fixHeight (p);
      fixHeight (q);
      return q;
   }

   public BinaryTreeNode<dataType> rotateLeft ( BinaryTreeNode<dataType> q )
   {
     /**
      * Makes a single left rotation of a nodes
      * Rotates to the left by replacing the right child with the left child
      * @return the rotated node
     */
      BinaryTreeNode<dataType> p = q.right;
      q.right = p.left;
      p.left = q;
      fixHeight (q);
      fixHeight (p);
      return p;
   }

   public BinaryTreeNode<dataType> balance ( BinaryTreeNode<dataType> p )
   {
      /**
       * Balaces each node by checking that the height difference between its
       * left and right subtrees is at most 1
       * If difference is higher than 1 it rotates the node appropriately
       * @return balanced tree after rotation(h) have been made
      */
      fixHeight (p);
      if (balanceFactor (p) == 2)
      {
         if (balanceFactor (p.right) < 0)
            p.right = rotateRight (p.right);
         return rotateLeft (p);
      }
      if (balanceFactor (p) == -2)
      {
         if (balanceFactor (p.left) > 0)
            p.left = rotateLeft (p.left);
         return rotateRight (p);
      }
      return p;
   }

   public void insert ( Dam d )
   {
      /**
       * Inserts a data item into the AVL tree when invoked
       * inCount() methods counts when insert() is invoked
       * @return Nothing
      */
      inCount();
      root = insert (d, root);
   }

   public BinaryTreeNode<dataType> insert ( Dam d, BinaryTreeNode<dataType> node )
   {
      /**
       * When inserting a node, it checks each node from the root node for a
       * position to insert a new node, counting at every node
       * @return new BinaryTreeNode
       * @return balance: balances tree after each instertion
      */
      if (node == null)
         return new BinaryTreeNode<dataType> (d, null, null);
      if (d.toString().compareTo (node.data) <= 0)
      {
         inCount();
         node.left = insert (d, node.left);
      }

      else
      {
         inCount();
         node.right = insert (d, node.right);
      }

      return balance (node);
   }

   public void delete ( String d )
   {
      /**
       * Removes a node from the AVL tree
      */
      root = delete (d, root);
   }
   public BinaryTreeNode<dataType> delete ( String d, BinaryTreeNode<dataType> node )
   {
      /**
       * Searches for data item with name d
       * When found, the node is set to null and the tree is balanced
      */
      if (node == null) return null;
      if (d.compareTo (node.data) < 0)
         node.left = delete (d, node.left);
      else if (d.compareTo (node.data) > 0)
         node.right = delete (d, node.right);
      else
      {
         BinaryTreeNode<dataType> q = node.left;
         BinaryTreeNode<dataType> r = node.right;
         if (r == null)
            return q;
         BinaryTreeNode<dataType> min = findMin (r);
         min.right = removeMin (r);
         min.left = q;
         return balance (min);
      }
      return balance (node);
   }

   public BinaryTreeNode<dataType> findMin ( BinaryTreeNode<dataType> node )
   {
      /**
       * @return the minimum of two child nodes
       * Used for inserting and searching operations
      */
      if (node.left != null)
         return findMin (node.left);
      else
         return node;
   }

   public BinaryTreeNode<dataType> removeMin ( BinaryTreeNode<dataType> node )
   {
      /**
       * Removes the minimum of the two child nodes
       * Balances the node after removing
      */
      if (node.left == null)
         return node.right;
      node.left = removeMin (node.left);
      return balance (node);
   }

   public BinaryTreeNode<dataType> find ( String d )
   {
      /**
       * When invoked, calls the recursive find method
      */
      if (root == null)
         return null;
      else
         return find (d, root);
   }

   public BinaryTreeNode<dataType> find ( String d, BinaryTreeNode<dataType> node )
   {
      /**
       * @param d is compared to every node data
       * Moves to left or right subtree depending on value of d
       * Counts number of comparison operations made when searching
       * @return node if found
      */
      opCount();
      int position = (node.data).indexOf(",");
      if (d.compareTo ((node.data).substring(0, position)) == 0)
         return node;

      else if (d.compareTo ((node.data).substring(0, position)) < 0)
         return (node.left == null) ? null : find (d, node.left);

      else
         return (node.right == null) ? null : find (d, node.right);
   }

   public void opCount ()
   {
     /**
      * @param opCount is incremented at each invocation
     */
      opCount++;
   }

   public void inCount()
   {
      /**
       * @param inCount is incrementedat each invocation
      */
      inCount++;
   }

   public int getOpCount ()
   {
     /**
      * @return opCount
     */
     return opCount;
   }

   public int getInCount()
   {
    /**
     * @return inCount
    */
     return inCount;
   }

}
