/**
 * <h1>Dam AVL class</h1>
 * @since 19 March 2018
 * @author Tlotliso Mapana
 *
*/

import java.util.Scanner;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DamAVLApp
{
  public static void printDam (String name, AVLTree<String> avl)
  {
    /**
     * Searches for a dam in the AVL tree given argument name
     * Prints out the data of the found dam
    */
    avl.find(name);
  }

  public static void printAllDams (AVLTree<String> avl)
  {
    /**
     * Prints all the dams in order or dam name
    */
    avl.inOrder();
  }

  /**
   * This is the main function
   * The file of dam details is read using FileReader and specific details
   * are then extracted
   * At each line, a new Dam object is initiated with the details extracted
   * from the file
   * There are two try and catch branches to handle file not found errors
  */
  public static void main ( String [] args )
  {
    Scanner inputFile = null;

    Dam dam = new Dam();
    BinaryTreeNode<String> node = new BinaryTreeNode<String> (dam, null, null);
    AVLTree<String> avlTree = new AVLTree<String> ();

    try { inputFile = new Scanner (new FileReader ("Dam_Levels_Sorted.csv")); }
    catch (FileNotFoundException err)
    {
      System.out.println("Error! Problem Opening File");
      System.exit(0);
    }

    inputFile.nextLine();
    double range = 0;
    while (inputFile.hasNextLine())
    {
      range++;
      String[] damDetails = inputFile.nextLine().split(",", -1);
      dam = new Dam(damDetails[2].trim(), damDetails[10].trim(), damDetails[42].trim());
      node = new BinaryTreeNode<String> (dam, null, null);
      avlTree.insert(dam);
    }

    if (args.length == 0)
      printAllDams(avlTree);

    else
    {

      try {
        printDam(args[0].trim(), avlTree);
        System.out.println(avlTree.getOpCount() + "," + avlTree.getInCount()/range);
      }

      catch (Exception e)
      {
        System.out.println("Dam not found");
        System.out.println("Comparison operations made for the search of " + args[0] + " is " + avlTree.getOpCount());
      }
    }

}

}
