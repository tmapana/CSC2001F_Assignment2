/**
 * <h1>Hussein's Binary Tree</h1>
 * @since 2 April 2017
 * @author Hussein Suleman
 *
*/

public class BinaryTree<dataType>
{
   /**
    * Creates a binary tree instance
    * @param root creates an instance of a node
    * Contains various operations to perform
   */
   BinaryTreeNode<dataType> root;

   public BinaryTree ()
   {
      root = null;
   }

   public int getHeight ()
   {
      /**
       * @return the height of a tree
      */
      return getHeight (root);
   }

   public int getHeight ( BinaryTreeNode<dataType> node )
   {
      if (node == null)
         return -1;
      else
         return 1 + Math.max (getHeight (node.getLeft ()), getHeight (node.getRight ()));
   }

   public int getSize ()
   {
      /**
       * @return the size of every node and recursiveky adds them
      */
      return getSize (root);
   }

   public int getSize ( BinaryTreeNode<dataType> node )
   {
      if (node == null)
         return 0;
      else
         return 1 + getSize (node.getLeft ()) + getSize (node.getRight ());
   }

   public void inOrder ()
   {
      /**
       * Traverses through the tree from leaf to root
       * Visits left child, node, and then right child until it gets to root
      */
      inOrder (root);
   }
   public void inOrder ( BinaryTreeNode<dataType> node )
   {
      if (node != null)
      {
         inOrder (node.getLeft ());
         visit (node);
         inOrder (node.getRight ());
      }
   }

   public void preOrder ( BinaryTreeNode<dataType> node )
   {
     /**
      * Traverses through the tree from root to leaf
      * Visits node, left child, and then right child until it gets to leaf
     */
      if (node != null)
      {
         visit (node);
         preOrder (node.getLeft ());
         preOrder (node.getRight ());
      }
   }

   public void postOrder ()
   {
     /**
      * Traverses through the tree from leaf to root
      * Visits left child, right child then node until it gets to root
     */
      postOrder (root);
   }
   public void postOrder ( BinaryTreeNode<dataType> node )
   {
      if (node != null)
      {
         postOrder (node.getLeft ());
         postOrder (node.getRight ());
         visit (node);
      }
   }

   public void visit ( BinaryTreeNode<dataType> node )
   {
      /**
       * Accesses the data of a node
      */
      System.out.println (node.data);
   }

}
