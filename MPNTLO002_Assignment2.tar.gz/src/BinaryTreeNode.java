/**
 * <h1>Hussein's Binary Tree Node class</h1>
 * @since 2 April 2017
 * @author Hussein Suleman
 *
*/

public class BinaryTreeNode<dataType>
{
   /**
    * Creates a BinaryTreeNode constructor and initialises variables
    * @param data contains string output from Dam.toString() method
    * @param left is left child
    * @param right is right child
    * @param height is the height of the node
    * Can access left and right children
   */

   String data;
   BinaryTreeNode<dataType> left;
   BinaryTreeNode<dataType> right;
   int height;

   public BinaryTreeNode ( Dam d, BinaryTreeNode<dataType> l, BinaryTreeNode<dataType> r )
   {
      data = d.toString();
      left = l;
      right = r;
      height = 0;
   }

   BinaryTreeNode<dataType> getLeft () { return left; }
   BinaryTreeNode<dataType> getRight () { return right; }

}
