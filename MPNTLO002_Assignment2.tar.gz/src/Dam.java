/**
 * <h1>Dam class</h1>
 * @since 06 March 2018
 * @author Tlotliso Mapana
 *
*/

public class Dam
{

  /**
   * Creates a Dam constructor and initialises variables
   * @param name contains string object name of dam
   * @param fsc is FSC of a dam
   * @param damLvl is the dam water level
  */
  String name;
  String fsc;
  String damLvl;

  public Dam (){}

  public Dam(String n, String f, String lvl)
  {
    /**
     * Initialises instance variables
    */
    name = n;
    fsc = f;
    damLvl = lvl;
  }

  public String getName ()
  {
    /**
     * @return name of a dam
    */
    return name;
  }

  public String getFSC()
  {
    /**
     * @return FSC of dam
    */
    return fsc;
  }

  public String getDamLevel()
  {
    /**
     * @return dam level
    */
    return damLvl;
  }

  public String toString ()
  {
    /**
     * Creates a new string with the instance variables and returns it
    */
    return name + ", the FSC is " + fsc + " and the most recent dam level is " + damLvl;
  }

  public boolean equalsTo(String n)
  {
    /**
     * checks if name and argument n have the same value
    */
    return getName().equals(n);
  }

}
